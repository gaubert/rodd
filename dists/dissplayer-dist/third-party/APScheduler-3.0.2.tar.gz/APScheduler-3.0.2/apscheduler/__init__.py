version_info = (3, 0, 2)
version = '3.0.2'
release = '3.0.2'

__version__ = release  # PEP 396
